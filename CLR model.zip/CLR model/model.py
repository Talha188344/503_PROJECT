import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.callbacks import LearningRateScheduler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from faker import Faker
fake = Faker()

# Generate a small fake dataset
# Generate a small fake dataset
fake_data_list = []
for _ in range(10000000):  # Generate 10 rows of fake data
    fake_row = {
        'Single CORE': fake.random_int(min=100, max=1000),
        'Multi Core': fake.random_int(min=100, max=2000),
        'GPU': fake.random_int(min=500, max=3000),
        'SSD': fake.random_int(min=50, max=500),
        'RAM': fake.random_int(min=4, max=32),
        'Budget': fake.random_element(elements=['Low', 'Medium', 'High'])
    }
    fake_data_list.append(fake_row)

# Convert the list of dictionaries into a DataFrame
fake_data = pd.DataFrame(fake_data_list)

# Load the original dataset from data.csv
data = pd.read_csv("workstation.csv")

# Concatenate the fake dataset with the original dataset
data = pd.concat([data, fake_data], ignore_index=True)

# Label encoding for the 'Budget' column
label_encoder = LabelEncoder()
data['Budget'] = label_encoder.fit_transform(data['Budget'])

# Separate features (X) and target variable (y)
X = data[['Budget']]
y = data[['Single CORE', 'Multi Core', 'GPU', 'SSD', 'RAM']]


# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Define a learning rate schedule for CLR
def cyclic_learning_rate(epoch, lr):
    base_lr = 0.001  # minimum learning rate
    max_lr = 0.01    # maximum learning rate
    step_size = 8    # step size (number of epochs in each cycle)

    cycle = np.floor(1 + epoch / (2 * step_size))
    x = np.abs(epoch / step_size - 2 * cycle + 1)
    new_lr = base_lr + (max_lr - base_lr) * np.maximum(0, 1 - x)

    return new_lr

# Define the neural network model
model = Sequential([
    Dense(128, activation='relu', input_shape=(1,)),
    Dense(256, activation='relu'),
    Dense(5)  # Output layer with 5 units for 5 output features
])

# Compile the model with SGD optimizer and initial learning rate
initial_learning_rate = 0.001
optimizer = SGD(learning_rate=initial_learning_rate)
model.compile(optimizer=optimizer, loss='mean_squared_error', metrics=['mse'])

# Define a learning rate scheduler callback
lr_scheduler = LearningRateScheduler(cyclic_learning_rate)

# Train the model with CLR
history = model.fit(X_train, y_train, epochs=50, batch_size=64, validation_split=0.3, callbacks=[lr_scheduler])

# Evaluate the model
loss, mse = model.evaluate(X_test, y_test)
print("Test Mean Squared Error:", mse)
