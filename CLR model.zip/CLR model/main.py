import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
# Load the data from data.csv
data = pd.read_csv("workstation.csv")

# Convert the 'Budget' column to numerical values using label encoding
label_encoder = LabelEncoder()
data['Budget'] = label_encoder.fit_transform(data['Budget'])

# Calculate the correlation matrix
correlation_matrix = data.corr()

# Extract the correlation of 'Budget' column with other features
budget_correlation = correlation_matrix['Budget'].drop('Budget')

# Plot the correlation values
plt.figure(figsize=(8, 6))
sns.barplot(x=budget_correlation.index, y=budget_correlation.values)
plt.title('Correlation between Budget and other features')
plt.xlabel('Features')
plt.ylabel('Correlation')
plt.xticks(rotation=45)
plt.show()